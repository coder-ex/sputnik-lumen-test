import React, { FC } from 'react';
import { Layout, Row, Menu } from "antd";
import { useHistory } from 'react-router-dom';
import { RouteNames } from "../router";


const Navbar: FC = () => {
    const router = useHistory()
    //console.log(router)
    const auth = true;
    return (
        <Layout.Header>
            <Row justify='end'>
                {auth
                    ?
                    <Menu theme='dark' mode='horizontal' selectable={false}>
                        <div style={{ color: 'white' }}>
                            Ulbi TV
                        </div>
                        <Menu.Item
                            onClick={() => console.log('Выйти')}
                            key={1}
                        >
                            Выйти
                        </Menu.Item>
                    </Menu>
                    :
                    <Menu theme='dark' mode='horizontal' selectable={false}>
                        <Menu.Item
                            onClick={() => router.push(RouteNames.LOGIN)}
                            key={1}
                        >
                            Логин
                        </Menu.Item>
                    </Menu>
                }

            </Row>
        </Layout.Header>
    );
};

export default Navbar;