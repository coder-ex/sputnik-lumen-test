import React, {FC} from 'react';

const Login:FC = () => {
    return (
        <div>
            LOGIN
        </div>
    );
};

export default Login;