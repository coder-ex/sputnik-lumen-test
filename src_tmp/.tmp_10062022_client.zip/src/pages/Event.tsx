import React, {FC} from 'react';

const Event: FC = () => {
    return (
        <div>
            EVENT PAGE
        </div>
    );
};

export default Event;